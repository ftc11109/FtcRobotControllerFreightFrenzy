package org.firstinspires.ftc.teamcode;

import java.io.File; // Import the File class
import org.firstinspires.ftc.robotcore.external.ExportToBlocks;
import java.io.FileNotFoundException; // Import this class to handle errors
import java.io.FileWriter; // Import the FileWriter class
import org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion;
import java.io.IOException; // Import the IOException class to handle errors

import java.util.Scanner; // Import the Scanner class to read text files

import android.os.Environment;


public class Files extends BlocksOpModeCompanion {
    @ExportToBlocks(comment = "Save to a file (custom block).", tooltip = "Save to a file.", parameterLabels = {
            "name", "value" })

    public static Boolean saveFile(String name, String value) {
        try {
            String logFilePath = String.format("%s/%s.txt",
            Environment.getExternalStorageDirectory().getAbsolutePath(), name);
            //"/sdcard", name);
            System.out.println(logFilePath);
            
            File myObj = new File(logFilePath);
            myObj.delete();
            myObj.createNewFile();
            FileWriter myWriter = new FileWriter(logFilePath);
            myWriter.write(value);
            myWriter.close();
            telemetry.addData("saveFile", "good");
            return true;
            
        

        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            telemetry.addData("saveFile", "error");
            return false;
        }
    }

    @ExportToBlocks(comment = "Read a file (custom block).", tooltip = "Read a file", parameterLabels = {
        "name" })

    public static String readFile(String name) {
        try {
            String logFilePath = String.format("%s/%s.txt",
            Environment.getExternalStorageDirectory().getAbsolutePath(), name);
            //"/sdcard", name);
            
            
            File myObj = new File(logFilePath);
            Scanner myReader = new Scanner(myObj);
            String data = myReader.nextLine();
            System.out.println(data);
            myReader.close();
            return data;

        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            return "";
        }
    }
}
